# Checklist before a prompt

No more than 10 items, each a short question. In brackets, the numbers of the "Mistake log" entries it comes from. Before every prompt, Claude shows a "Check" block: for every item "yes" or "no" with a short note. The prompt is shown only after your "ok".

Below are examples of the format. Replace them with your own when entries appear in the log.

1. Is the size of the hero and the main objects given? (# …)
2. Does it say how many heroes are in the frame? (# …)
3. If there is a picture or a file: did I open it and write what I can see in it? (# …)
4. Does the prompt avoid repeating the techniques of earlier scenes? (# …)
5. How many attempts have already been made on this scene? If two, options first, then a new prompt. (# …)
