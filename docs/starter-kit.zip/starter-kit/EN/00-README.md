# Starter Kit: templates for your Claude project

These are empty files from the guide "How to set up Claude for creating reels and Instagram posts". They save you from creating every file from scratch. They contain nobody's numbers, authors or characters: you fill everything in yourself.

## How to use
1. Open your project in Claude. The **Context** block → **Add** → upload the files you need from this folder (all at once is fine).
2. Open the project's file list and check that the files appeared.
3. You do not need to upload file 07: open it and copy the text of the task you need into the project chat. Upload files 01–06, and do not upload both language folders. If the project already has a file with the same name, do not upload the new one over it: first save a copy of your own.
4. Claude fills the files in using the phrases from the guide. It adds rows and does not erase the old ones. It saves only on your words ("save the file", "save the entry", and so on).
5. Before the first run of any scheduled task, download copies of your files.

## What is in the kit
| File | What it is for | Guide section |
| --- | --- | --- |
| 01-results-log.md | One row per reel: numbers from the statistics | 9 |
| 02-hypothesis-log.md | Ideas you are testing, and the rules for conclusions | 9 |
| 03-digest-of-other-reels.md | Issues about other people's successful reels | 10 |
| 04-mistake-log.md | Mistakes and their causes | 12 |
| 05-checklist-before-a-prompt.md | A short check before a prompt | 12 |
| 06-weekly-report.md | A sample weekly report | 9 |
| 07-scheduled-tasks.md | Ready texts for four scheduled tasks | 8, 9, 10, 11 |

## Important
- Square brackets [ ] hold what you need to replace with your own. Delete the brackets themselves.
- Do not put passwords or personal data into the files.
- Button names in Claude and Instagram may differ from the ones in the guide.
