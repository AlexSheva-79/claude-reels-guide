# Digest of other people's successful reels

Note: issues go from top to bottom, the newest always on top. At the bottom is the "Already shown" section with links to the reels already shown, so they do not repeat. Authors are called "author A", "author B", but every reel has a link. Dates: DD.MM.YYYY. An issue is written into the file only after your words "save the issue".

## Issue of [DD.MM.YYYY]
My niche and style: [what you make and in what style]. Window: the last 14 days, from 50 thousand views.

| Author | Link | Views | How many times more than usual | What is in the reel |
| --- | --- | --- | --- | --- |
| | | | | |

**What repeats.** Techniques that appeared at several authors.

**What you can try.**

**Careful.** What could not be checked; the descriptions of reels in vidIQ are written by a program.

(put new issues above this line, do not delete old ones)

## Already shown
Links to reels from earlier issues:

(empty for now)
