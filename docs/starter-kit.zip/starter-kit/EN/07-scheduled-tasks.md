# Ready texts for scheduled tasks

These are the same phrases as in the guide. Copy the text from the block, replace the words in square brackets with your own and send it in the project chat. How to create such tasks and connect Gmail, Google Drive and vidIQ is in section 8.

**What to replace:** [city] or [your city] is your city (so that the run time is your local time, not the server's); [address of the connected Gmail] is the address the email will go to (type it without typos, the email must not go to a stranger); [describe what you make and in what style] is your niche. Delete the brackets themselves.

**Before the first run:** download copies of the files the task will change. Scheduled tasks spend vidIQ credits on every run, and you can switch tasks off in the task list of your app. For a test run, write in the chat: "Run this task right now, once". It runs for real.

## Task 1: daily measurement (section 9)
Finds reels that are 3–5 days old and adds them to the results log.

```
Create a scheduled task. If Gmail isn't connected, tell me first and don't create the task. My time zone: [your city]. When: every 2 days at 12:00. What to do: read the results log and the hypothesis log in the project. If a file is missing, create nothing and send an email with the subject "Task error". Through vidIQ find my reels published 3–5 days ago. Before writing, check by publish date and caption start that such a row doesn't exist yet. For each one calculate exactly: views, skipped %, average watch time, watched %, saved %, shared %. If vidIQ doesn't provide a metric, put a dash and don't derive it from others. Only add new rows at the end of the log; don't change or delete existing rows or files. Determine the group from the hypothesis log; if it isn't specified, write "group not specified". If there are enough reels for a conclusion under the log's rules, write the conclusion to the hypothesis log with the status "waiting for my confirmation". Only read account data; publish and change nothing. Email me only at [address of the connected Gmail] and only if there is a new conclusion or the task could not run (subject "Task error"). First briefly retell how you understood the task, then ask me all your questions now, at creation. When running on schedule, ask nothing: if something is missing, skip that step and say so in the email.
```

## Task 2: weekly review (section 9)
Builds a weekly report into a new file and sends the key findings by email.

```
Create a scheduled task. If Gmail isn't connected, tell me first and don't create the task. My time zone: [your city]. When: every Monday at 10:00. What to do: through vidIQ take my reels from the last 7 days. Show reels younger than 3 days on a separate line and leave them out of conclusions; give each reel's age in the table. Build the report from these parts: Summary; Reels table (age, views, skipped %, average watch time, saved %, shared %); What got lots of views and what dropped (compare with the median of my reels over the last 4 weeks); What to watch next; What to change; What the data is missing (what vidIQ doesn't provide). If the project has a previous report of the same kind, compare with it. Calculate numbers exactly. Don't draw conclusions from data that isn't there. Only read account data. Save the report in the project as a new file named like 2026-10-05-statistika.md (the Monday's date); if that file already exists, add -2 to the name and don't replace it. Email me a short summary of 3–5 sentences only at [address of the connected Gmail]. If you couldn't complete the task, send a short email with the subject "Task error". First briefly retell how you understood the task, then ask me all your questions now, at creation. When running on schedule, ask nothing: if something is missing, skip that step and say so in the email.
```

## Task 3: Friday digest issue (section 10)
Looks for other people’s successful reels, adds an issue to the file and records an idea in the hypothesis log with the status "waiting for my confirmation".

```
Create a scheduled task. First briefly repeat how you understood the task and ask all your questions now. Create the task only when I write "ok".
If Gmail is not connected, tell me and do not create the task. My city for the time: [city]. When: every Friday at 18:00.
What to do on every run:
1. Read the file "Digest of other people's successful reels" and the hypothesis log file in the project. If either file is missing, create nothing and send an email with the subject "Task error".
2. If the file already has an issue for today's date, add nothing.
3. Before writing, save a copy of the digest file to the project as a new file with the date in its name. Do not delete old copies.
4. Use vidIQ for no more than two searches. Look for Instagram reels that got far more views than their authors usually get. My niche and style: [describe what you make and in what style]. Last 14 days, from 50 thousand views. One search by niche, the second by strong openings (the first three seconds). Do not use other sources. If vidIQ returns an error, do not repeat the request, send an email with the subject "Task error".
5. Do not take reels from "Already shown". Remove films and series, app ads, tool demos, other people's famous characters, anything outside my niche. Call authors "author A", "author B", but give a link for every reel.
6. Write an issue: a table (author, link, views, how many times more than usual, what is in the reel); "What repeats"; "What you can try"; "Careful". If vidIQ does not show something, put a dash and invent nothing. If there are no suitable reels, write nothing to the file and say so in the email.
7. Only add: insert the issue at the top of the file, write the shown reels at the bottom in "Already shown". Do not change or delete anything old.
8. If "What repeats" has repeats, pick ONE idea and record it as a new row at the end of the hypothesis log: status "waiting for my confirmation", source "digest", date of the issue. Do not change old rows. If an idea with the same meaning is already there, do not add a new row, and say in the email that it repeated.
9. Publish nothing on Instagram. Send an email only to me, at [address of the connected Gmail]. Write to no one else and do not reply to emails. In the email: key findings in 3–5 sentences, the idea, and a note on whether it was recorded in the log. If you could not do the task, send a short email with the subject "Task error".
When it runs on schedule, ask me nothing: if something is missing, skip that step and say so in the email.
```

## Task 4: reminder about a Stories announcement (section 11)
Sends an email on the day the reel comes out if the "Stories announcements" folder on Google Drive has a file with today’s date.

```
Create a scheduled task. First briefly repeat how you understood the task and ask all your questions now. Create the task only when I write "ok".
If Gmail or Google Drive is not connected, tell me and do not create the task. My city for the time: [city]. When: every day at 12:00.
What to do on every run:
1. Open the folder "Stories announcements" on Google Drive. If it does not exist, send an email with the subject "Task error" to the same address.
2. Find in it a file whose name starts with today's date as YYYY-MM-DD.
3. If the file exists (if several files have that date, one email with all the links), send an email with a link to it and the words: "A reel comes out today. Post the announcement in Stories".
4. If there is no file, send nothing.
5. Only read. Do not delete, rename, publish anything or change file sharing. Send the email only to me, at [address of the connected Gmail], to no one else, and do not reply to emails. If the address is missing, do not send the email.
When it runs on schedule, ask me nothing: if something is missing, skip that step and say so in the email.
```
