# Mistake log

Every mistake is recorded right away. The cause may be in the prompt or elsewhere; if the cause is unclear, say so. New entries are added as a row at the end. Dates: DD.MM.YYYY.

| # | Where (reel or scene) | Symptom | Cause | Rule |
| --- | --- | --- | --- | --- |
| | | | | |
