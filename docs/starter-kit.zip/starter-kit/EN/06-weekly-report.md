# Weekly report

A sample of what a weekly report should look like. New reports are saved as separate files named YYYY-MM-DD-statistics.md (the date of Monday). Numbers are calculated exactly. If vidIQ does not show something, put a dash.

## Summary
Two or three sentences about the week.

## Table of reels
Reels younger than 3 days are shown in a separate row and are not part of the conclusions.

| Age | Views | Skipped % | Average watch time | Saved % | Shared % |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## What got many views and what dropped
Compare with the median of your reels over the last 4 weeks.

## What to watch next

## What to change

## What is missing in the data
What vidIQ or the statistics did not show.
