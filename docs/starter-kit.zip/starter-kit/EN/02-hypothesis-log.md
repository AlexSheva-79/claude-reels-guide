# Hypothesis log

A hypothesis is an idea you test in one reel. For each one, write: where it came from, how to apply it, the **main metric** (the number we judge by: skipped or watched; views do not work) and the status.

## Rules for conclusions
- One change per reel.
- We draw a conclusion about a hypothesis when there are at least 3 "test" reels and at least 3 "control" reels.
- If the main metric of every test is better than that of all controls, the status is "seems to have helped". If every test is worse than all controls, "seems not to have helped". Otherwise "no visible difference".
- While there are fewer than three tests, there is no conclusion.
- Rows with the group "not specified" are not used in conclusions.
- Every conclusion is rechecked with one more reel.
- Allowed statuses: "testing", "waiting for my confirmation", "seems to have helped", "seems not to have helped", "no visible difference".

## Hypotheses
| # | Hypothesis | Where it came from | How to apply | Main metric | Status |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

## Conclusions we apply
Hypotheses with the status "seems to have helped" move here. These are the rules for the next reels.

(empty for now)
