# Reel results log

One row per reel. Measure on day 3 after release, from a screenshot of the statistics. If a number is missing, put a dash "–" and do not calculate it from other figures. Write dates as DD.MM.YYYY.

Group: "control" (a regular reel with no idea being tested) or "test #N" (a reel with hypothesis number N from the hypothesis log).

| Release date | First words of the caption | Length, sec | Views | Skipped % | Average watch time | Watched % | Saved % | Shared % | Group | Measured on |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | |
